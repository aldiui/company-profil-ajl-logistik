<?php if($kategori == 'Retail'): ?>
    <div class="table-responsive">
        <table class="table table-bordered table-striped" id="retail-price-table" width="100%">
            <thead class="text-center">
                <tr>
                    <th>Origin</th>
                    <th>Destination Kota</th>
                    <th>Kode</th>
                    <th>Harga 0-70 Kg</th>
                    <th>Harga 71+ Kg</th>
                    <th>Estimasi</th>
                </tr>
            </thead>
            <tbody class="text-center">
                <?php if($tarif): ?>
                    <tr>
                        <td><?php echo e($tarif->distributionCenter->nama); ?></td>
                        <td><?php echo e($tarif->city->nama); ?></td>
                        <td><?php echo e($tarif->city->kode); ?></td>
                        <td><?php echo e(formatRupiah($tarif->harga_dibawah_tujuh_puluh)); ?></td>
                        <td><?php echo e(formatRupiah($tarif->harga_diatas_tujuh_puluh)); ?></td>
                        <td><?php echo e($tarif->estimasi_hari); ?> Hari</td>
                    </tr>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="bg-danger bg-opacity-25">
                            <i class="bi bi-exclamation-triangle-fill me-3"></i> Data
                            Tidak
                            Ditemukan
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-bordered table-striped" id="retail-price-table" width="100%">
            <thead class="text-center">
                <tr>
                    <th>Rute</th>
                    <th>Blind Van</th>
                    <th>CDE Box</th>
                    <th>CDD Box</th>
                    <th>Fuso Box</th>
                    <th>Wing Box</th>
                </tr>
            </thead>
            <tbody class="text-center">
                <?php if($tarif): ?>
                    <tr>
                        <td><?php echo e($tarif->rute); ?></td>
                        <td><?php echo e(formatRupiah($tarif->blind_van)); ?></td>
                        <td><?php echo e(formatRupiah($tarif->cde_box)); ?></td>
                        <td><?php echo e(formatRupiah($tarif->cdd_box)); ?></td>
                        <td><?php echo e(formatRupiah($tarif->fuso_box)); ?></td>
                        <td><?php echo e(formatRupiah($tarif->wing_box)); ?></td>
                    </tr>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="bg-danger bg-opacity-25">
                            <i class="bi bi-exclamation-triangle-fill me-3"></i> Data
                            Tidak
                            Ditemukan
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\compro-ajl-logistik\resources\views/pages/frontend/table-tarif.blade.php ENDPATH**/ ?>