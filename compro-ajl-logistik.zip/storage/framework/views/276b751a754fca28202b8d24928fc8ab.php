<div id="sidebar">
    <div class="sidebar-wrapper active">
        <div class="container text-center mt-4">
            <a href="/admin">
                <img src="<?php echo e(asset('frontend/assets/logo.png')); ?>" width="120px" alt="Logo - <?php echo e(config('app.name')); ?>">
            </a>
        </div>
        <div class="sidebar-menu">
            <ul class="menu mb-5">
                <li class="sidebar-item <?php echo e(request()->is('admin') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('/admin')); ?>" class='sidebar-link'>
                        <i class="bi bi-grid-fill"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo e(request()->is('admin/distribution-center') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('/admin/distribution-center')); ?>" class='sidebar-link'>
                        <i class="bi bi-house"></i>
                        <span>Distribution Center</span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo e(request()->is('admin/city') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('/admin/city')); ?>" class='sidebar-link'>
                        <i class="bi bi-geo-alt"></i>
                        <span>Kota</span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo e(request()->is('admin/retail-price') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('/admin/retail-price')); ?>" class='sidebar-link'>
                        <i class="bi bi-cash"></i>
                        <span>Harga Retail</span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo e(request()->is('admin/trucking-price') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('/admin/trucking-price')); ?>" class='sidebar-link'>
                        <i class="bi bi-truck"></i>
                        <span>Harga Trucking</span>
                    </a>
                </li>
                <li class="sidebar-item mb-5">
                    <a href="<?php echo e(url('/logout')); ?>" class='sidebar-link text-danger'>
                        <i class="bi bi-arrow-right-circle-fill text-danger"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\compro-ajl-logistik\resources\views/components/sidebar-backend.blade.php ENDPATH**/ ?>