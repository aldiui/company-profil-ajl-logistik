<?php $__env->startSection('title', 'Cabang'); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <header class="container py-5">
        <div class="row py-5">
            <div class="col-12 text-center mb-4">
                <h2 class="fw-bold text-ajl-secondary mb-3">Cabang</h2>
            </div>
            <?php $__currentLoopData = $distributionCenters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="card shadow-sm border-ajl-primary h-100 p-2 rounded-4">
                        <div class="card-body">
                            <div class="mb-2">
                                <i class="bi bi-truck text-ajl-primary fs-1"></i>
                            </div>
                            <h5 class="fw-bold text-dark mb-3"><?php echo e($row->kode); ?></h5>
                            <div class="mb-2 d-flex align-items-start">
                                <i class="bi bi-building me-3"></i>
                                <span><?php echo e($row->nama); ?></span>
                            </div>
                            <div class="mb-2 d-flex align-items-start">
                                <i class="bi bi-geo-alt  me-3"></i>
                                <span><?php echo e($row->alamat ?? '-'); ?></span>
                            </div>
                            <div class="mb-2 d-flex align-items-start">
                                <i class="bi bi-telephone  me-3"></i>
                                <span><?php echo e($row->telepon ?? '-'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </header>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\compro-ajl-logistik\resources\views/pages/frontend/cabang.blade.php ENDPATH**/ ?>