<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name')); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('backend/compiled/svg/favicon.svg')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('backend/compiled/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/compiled/css/iconly.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/static/css/style.css')); ?>">
    <?php echo $__env->yieldPushContent('style'); ?>
</head>

<body>
    <div class="container">
        <?php echo $__env->yieldContent('main'); ?>
    </div>
    <script src="<?php echo e(asset('backend/extensions/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/compiled/js/app.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script src="<?php echo e(asset('backend/static/js/custom.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\compro-ajl-logistik\resources\views/layouts/auth.blade.php ENDPATH**/ ?>