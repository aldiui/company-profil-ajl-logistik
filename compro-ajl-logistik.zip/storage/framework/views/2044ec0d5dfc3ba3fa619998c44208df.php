<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="content-wrapper container">
        <div class="page-heading">
            <h3><?php echo $__env->yieldContent('title'); ?></h3>
        </div>
        <div class="page-content">
            <section class="row">
                <div class="col-6 col-lg-3 col-6">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="bi bi-house text-success fs-1 mb-4"></i>
                            <h6 class="text-muted font-semibold">Distribution Center</h6>
                            <h6 class="font-extrabold mb-0"><?php echo e($dc); ?></h6>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-6">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="bi bi-geo-alt text-info fs-1 mb-4"></i>
                            <h6 class="text-muted font-semibold">Kota</h6>
                            <h6 class="font-extrabold mb-0"><?php echo e($kota); ?></h6>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-6">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="bi bi-cash text-primary fs-1 mb-4"></i>
                            <h6 class="text-muted font-semibold">Harga Retail</h6>
                            <h6 class="font-extrabold mb-0"><?php echo e($hargaRetail); ?></h6>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-6">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="bi bi-truck text-danger fs-1 mb-4"></i>
                            <h6 class="text-muted font-semibold">Harga Truck</h6>
                            <h6 class="font-extrabold mb-0"><?php echo e($hargaTrucking); ?></h6>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\compro-ajl-logistik\resources\views/pages/backend/dashboard/index.blade.php ENDPATH**/ ?>