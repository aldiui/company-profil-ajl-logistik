<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name')); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('backend/compiled/svg/favicon.svg')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('backend/compiled/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/compiled/css/iconly.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/static/css/style.css')); ?>">
    <?php echo $__env->yieldPushContent('style'); ?>
</head>

<body>
    <script src="<?php echo e(asset('backend/static/js/initTheme.js')); ?>"></script>
    <div id="app">
        <?php echo $__env->make('components.sidebar-backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="main" class='layout-navbar navbar-fixed'>
            <?php echo $__env->make('components.header-backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="main-content">
                <?php echo $__env->yieldContent('main'); ?>
                <?php echo $__env->make('components.footer-backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('backend/extensions/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/extensions/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/compiled/js/app.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script src="<?php echo e(asset('backend/static/js/custom.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\compro-ajl-logistik\resources\views/layouts/backend.blade.php ENDPATH**/ ?>